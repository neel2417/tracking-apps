export const GOOGLE_MAP_KEY = "paste here your google key"
